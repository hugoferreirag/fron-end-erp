<template>
    <div class="home col-md-12">
    <h4>    sa</h4>
       
    </div>
</template>

<script>

import axios from 'axios'


export default {
    name: 'Home',
    components: { },
    data: function() {
        return {
            stat: {}
        }
    },
    methods: {
      
    },
  
}
</script>

<style>
    .stats {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }
</style>
