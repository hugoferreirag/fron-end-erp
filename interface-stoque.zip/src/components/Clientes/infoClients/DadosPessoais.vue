<template>
    <div>

        <div style="margin-bottom:60px; text-align:center" id="tableoption" class="col-md-12 row justify-center">
            <div class="col-md-2">
             ||<b-button   @click="remove">  Remover<img src="@/assets/images/deletar.png" width="20" alt=""></b-button>||
            </div>
            <button @click="clow">sasa</button>
            <h6>{{cliente_id.name}} + as</h6>

           
        </div>
      <div class="row "  justified align="center">
          <div class="col-md-6 ">
               <b-img thumbnail fluid :src="cliente_id.picture" width="350" style="height:400px" alt="Perfil"></b-img>
          </div>
          <div :class="'col-md-3 ' + dait " align="center">
              <label for="">Name:</label><br>
              <input  :disabled="validity" :value="cliente_id.picture" type="text"><br>
              <label for="">Email:</label><br>
              <input :disabled="validity" :value="cliente_id.email" type="text"><br>
              <label for="">Endereço:</label><br>
              <input :disabled="validity" :value="cliente_id.adress" type="text"><br>
              <label for="">Endereço Comercial:</label><br>
              <input :disabled="validity" :value="cliente_id.business_adress" type="text"><br>
              <label for="">Telefone:</label><br>
              <input :disabled="validity" :value="cliente_id.cel" type="text"><br>
              <br>
              <b-button v-if="validity==true" @click="validity = false, dait = 'dait'" variant="primary">Editar</b-button> 
              <b-button v-else @click="validity = true, dait = ''" variant="danger">Cancelar</b-button>  ||
              <b-button v-show="validity == false" variant="warning">Confirmar</b-button> 
          </div>
      </div>
    </div>
</template>

<script>
import { mapActions, mapMutations } from 'vuex'

import { setTimeout } from 'timers';
export default {
    components:{   },
    name:"dadospessoais",
    props:['id'],

    data(){
        return{
            validity:true,
            dait:''
        }
    },
    computed:{
        userId(){
            return this.$store.state.Auth.userId
        },
        cliente_id(){
            return this.$store.state.Clientes.cliente_id
        }
    },
    methods:{
        ...mapActions('Auth',['getUser']),
        ...mapMutations('Clientes',['setClient_id']),
        

         async  buscarUsuario(){
          await  this.$http.get('/user/'+2)
            .then(result=>{
                this.getUser(result.data)
            }).catch()
            
        },
        async clow(){
            const result = await this.$http.get('clientes/'+this.id).then()
            this.setClient_id(result.data)
        },
        remove(){
            var push= false;
            this.$http.delete(`user/${this.id}`)
            .then(result=>{
                if(result.status == 201){
                
                this.$router.push({name:'hierarquia'})
                
                }else{
                this.$bvToast.toast('Ooops, houve algum erro',{title:'Ação má sucedida',variant:'warning'})
                }
                
          
            })
            .catch()
        }

    },
    created(){

    },
    mounted(){
        this.clow()
    }
}
</script>
<style >
    .dait input{
        background-color:yellowgreen
    }
</style>;
