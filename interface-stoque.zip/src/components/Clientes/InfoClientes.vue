<template>
    <div>

        <div style="margin-bottom:60px; text-align:center" id="tableoption" class="col-md-12 row justify-center">
            <div class="col-md-2">
             ||<b-button   @click="remove">  Remover<img src="@/assets/images/deletar.png" width="20" alt=""></b-button>||
            </div>
            

           
        </div>
        <div class="container row box">
            <router-link  dados_pessoais class="col-md-3" :to="`/clientes/dados_pessoais/${this.id}`">
            <div >
                <h6>Dados Pessoais  </h6>
            </div>
            </router-link>
            <div documentos class="col-md-3">
               <h6> Documentos </h6>
            </div>
            <div dados_validatorios class="col-md-3">
                <h6>Dados Validatórios</h6>
            </div>
            <div veiculos class="col-md-3">
                <h6>Veículos</h6>
            </div>
            <div imagens class="col-md-3">
                <h6>Imagens</h6>
            </div>
            <div conquistas class="col-md-3" >
                <h6>Conquistas</h6>
            </div>
        </div>
    </div>
</template>

<script>
import { mapActions, mapMutations } from 'vuex'
import dados_pessoais from '../Clientes/infoClients/DadosPessoais'
import { setTimeout } from 'timers';
export default {
    components:{ dados_pessoais,  },
    name:"infoUser",
    props:['id'],

    data(){
        return{

        }
    },
    computed:{
        userId(){
            return this.$store.state.Auth.userId
        },
        cliente(){
            return this.$store.state.Clientes.cliente_id
        }
    },
    methods:{
        ...mapActions('Auth',['getUser']),
        ...mapMutations('Clientes',['setClient_id']),
      
         async  buscarUsuario(){
          await  this.$http.get('/user/'+ this.id)
            .then(result=>{
                this.getUser(result.data)
            }).catch()
            
        },
        async setCliente(){
            const cliente = await this.$http.get('clientes/'+this.id).then()
            this.setClient_id(cliente.data)
        },
        remove(){
            var push= false;
            this.$http.delete(`user/${this.id}`)
            .then(result=>{
                if(result.status == 201){
                
                this.$router.push({name:'hierarquia'})
                
                }else{
                this.$bvToast.toast('Ooops, houve algum erro',{title:'Ação má sucedida',variant:'warning'})
                }
                
          
            })
            .catch()
        }

    },
    created(){

    },
    mounted(){
        this.buscarUsuario()
        this.setCliente()
    }
}
</script>
<style >
    .box{
        background-image:linear-gradient(to right,rgb(180, 223, 240),rgb(180, 223, 240));
        border:rgb(179, 225, 236) 2px solid;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 20px;
    }
    .user h5{
        font-family: 'Courier New', Courier, monospace;
        font-weight:bold !important
    }
    [dados_pessoais]{
        color:white;
       background:url('~@/assets/images/pessoais.png') no-repeat 80% rgb(22, 187, 146);
       background-size: 130px 100px ;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px
    }
    [dados_pessoais]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
    [documentos]{
        color:white;
        background:url('~@/assets/images/documento.png') no-repeat 80% teal;
        background-size:130px 110px;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px
    }
     [documentos]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
    [veiculos]{
        color:white;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px;
        background:url('~@/assets/images/veiculo.png') no-repeat 80% tomato
    }
     [veiculos]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
    [dados_validatorios]{
        color:white;
        background:url('~@/assets/images/checkform.png') no-repeat 85% 1% yellowgreen;
        background-size: 130px 110px;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px
    }
     [dados_validatorios]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
    [imagens]{
        color:white;
         background:url('~@/assets/images/imagens.png') no-repeat 80% deepskyblue;
         background-size: 130px 110px;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px
    }
     [imagens]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
    [conquistas]{
        color:white;
         background:url('~@/assets/images/conquistas.png') no-repeat 80% goldenrod;
         background-size:130px 110px;
        margin:45px;
        height:100px;
        border-radius:5px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: bold;
        padding:5px
    }
     [conquistas]:hover{
        box-shadow: 1px 1px 2px 2px black
    }
</style>;
