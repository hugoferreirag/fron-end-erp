<template>
  <div class="col-md-12">
    <div class="row">
  
      
      <div id="tableoption" class="col-md-12">
        
        <div style="text-align:center  " class="">
          <b-button  @click="$router.push(`clientes/newCLiente`)" v-show="user.cargo == 1" sm v-b-modal.modal-lg>Novo Usuário<img src="@/assets/images/adicionar.png" width="25" alt=""></b-button>    
        </div>
      
      </div>
    
    </div>
    <Getusers />
  </div>
</template>
<script>
import TitlePage from "../Template/TitlePage";
import Getusers from "../Clientes/componentsClients/Lista";


export default {
  name: "hierarquia",
  components: { TitlePage, Getusers },
  data() {
    return {
      newUser: {
        cargo_id: 3
      }
    };
  },
  computed: {
    user() {
      return this.$store.state.Auth.user;
    },

  }
};
</script>
<style>

input {
  border: 1px grey solid;
  border-radius: 10px;
}
select {
  border: 1px grey solid;
  border-radius: 10px;
}
</style>