<template>
<div class="row form">
    <div step1 class="col-md-3">
        <h6>Dados Pessoais</h6>
         <label for="">Nome Completo:</label> <br>       
         <input v-model="cliente.name" type="text"> <br>
         <label for="">Email</label> <br>
         <input required v-model="cliente.email" type="email"><br>
         <label for="">Cel</label><br>
         <input v-model="cliente.cel" type="text"><br>
         <label for="">Tel</label><br>
         <input v-model="cliente.tel" type="text"><br>
         <label for="">Enedereço</label><br>
         <input v-model="cliente.adress" type="text"><br>
         <label for="">Profissão</label><br>
         <input v-model="cliente.profissao" type="text"><br>
         <label for="">Endereço Comercial</label><br>
         <input v-model="cliente.business_adress" type="text"><br>


    </div>
    <div step1 class="col-md-3">
        <h6>Dados De Documentos</h6>
         <label for="">CPF:</label> <br>       
         <input v-model="cliente.cpf" type="text"> <br>
         <label for="">RG</label> <br>
         <input required v-model="cliente.rg" type="text"><br>
         <label for="">Orgão Expeditor</label><br>
         <input v-model="cliente.organ_xpd" type="text"><br>
         <label for="">Data de Emissão</label><br>
         <input v-model="cliente.document_emission" type="date"><br>
         <label for="">Nacionalidade</label><br>
         <input v-model="cliente.nacionality" type="text"><br>
         <label for="">Naturalidade</label><br>
         <input v-model="cliente.naturality" type="text"><br>
         <label for="">Estado Civil</label><br>
         <input v-model="cliente.civil_status" type="text"><br>
         <label for="">Nome do Pai</label><br>
         <input v-model="cliente.father_name" type="text"><br>
         <label for="">Nome da Mãe</label><br>
         <input v-model="cliente.mother_name" type="text"><br>
         <label for="">Data de Nascimento</label><br>
         <input v-model="cliente.date_of_birth" type="date"><br>
    </div>
    <div step1 class="col-md-3">
        <h6>Dados Validatórios</h6>
         <label for="">Número do CR:</label> <br>       
         <input v-model="cliente.cr_number" type="text"> <br>
         <label for="">Data do CR</label> <br>
         <input required v-model="cliente.cr_date" type="date"><br>
         <label for="">Validade do CR</label><br>
         <input v-model="cliente.cr_validity" type="date"><br>
            <br><br>
         <b-button style="float:right; margin-right:70px" variant="info" @click="cliente = {}">Limpar</b-button>
         <b-button style="float:right; margin-right:70px" variant="success" @click="newClient">Salvar</b-button>
    </div>
</div>
</template>
<script>
import { mapActions } from 'vuex'
export default {
    data(){
        return{
            cliente:{}
        }
    },
    created(){
        console.log('new')
    },
    methods:{
        ...mapActions('Clientes',['setClientes']),
          toast(content, title, variant){
                this.$bvToast.toast(`${content}`, {
                    title: `${title}`,
                    toaster: 'b-toaster-top-center',
                    solid: true,
                    appendToast: true,
                    variant:`${variant}`
                    })
            },
        async newClient(){
            console.log('okok')
            await this.$http.post('/clientes', this.cliente)
            .then(result=>{
                   if(result.status == 200){ 
                 this.toast('Cliente cadastrado com sucesso',
                'Ação bem sucedida',
                'success')
                    this.cliente = {}
                }else{
                    this.toast(result.data,
                'Ação má sucedida',
                'danger')

                }
                this.setClientes()
            })
        }

    }
}
</script>
<style >
    [step1]{
        background-color:rgba(222,222,222,0.2);
        border-radius: 20px; 
        padding:10px;
        margin-right: 10px
    }
    [step1]:hover{
        box-shadow: 1px 1px 4px 3px;
    }
    .form{
        
        justify-content: center;
    }
    .form label{
        font-weight: bold;
        font-family: 'Courier New', Courier, monospace
    }
    .form input{
        width:230px
    }
    .form h6{
        font-weight: bold;
        font-family: 'Courier New', Courier, monospace;
        margin-bottom:20px
    }
</style>