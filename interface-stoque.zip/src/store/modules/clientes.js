import axios from 'axios'
export default {
  namespaced: true,
  state: {
    items: [],
    cliente_id: []
  },
  mutations: {
    setClientes (state, payload) {
      state.items = payload
    },
    setClient_id (state, payload) {
      state.cliente_id = payload
    }
  },
  actions: {
    setClientes ({ commit }) {
      axios.get('/clientes')
        .then(result => {
          console.log(result.data)
          commit('setClientes', result.data)
        })
    }
  }
}
